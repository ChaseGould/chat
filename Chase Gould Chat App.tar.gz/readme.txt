Chase Gould
Comp 429
3/7/2019
Project 1

I opted to not have a partner for this project. I have completed the project entirely on my own.
Any code borrowed from the interntet has been cited within my source code.

I have implemented my app as two seperate programs one for the client and one for the server.
Both programs are written in the C programming linux and are compatible with the linux system.

The client program contains all of the requested operations i.e Connect, Send, MyIP...
The server program can receive messages from clients and send messages back to the client.

The command to run the client program is ./client <port number>
the command to run the server program is ./server <port number>

